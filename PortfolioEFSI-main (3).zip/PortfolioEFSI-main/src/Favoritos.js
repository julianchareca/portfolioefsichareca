import React from "react";

const Favoritos = () => {

}

export default Favoritos;