import React from "react";

const Info = () => {

}

export default Info;